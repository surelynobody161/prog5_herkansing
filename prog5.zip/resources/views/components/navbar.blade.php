<nav>
    @if(Route::has('login'))
    <a> href={{route('welcome')}}home</a>
        <a> href={{route }}</a>

    @else
</nav>
